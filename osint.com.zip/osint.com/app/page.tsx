"use client"

import { useState, useEffect, useRef } from "react"
import { toolsData } from "@/data/tools"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Search,
  Grid3X3,
  List,
  Download,
  ExternalLink,
  X,
  Filter,
  ChevronRight,
  Terminal,
  Shield,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { createClient } from "@supabase/supabase-js"
import type { Tool } from "@/types/tool"

// Initialize Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://example.supabase.co"
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "example-key"
const supabase = createClient(supabaseUrl, supabaseKey)

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [showWelcomeModal, setShowWelcomeModal] = useState(true)
  const [viewMode, setViewMode] = useState("grid")
  const [isScanning, setIsScanning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [scanComplete, setScanComplete] = useState(false)
  const [threatCount, setThreatCount] = useState(0)
  const [showScanModal, setShowScanModal] = useState(false)
  const [tools, setTools] = useState<Tool[]>(toolsData)
  const [isLoading, setIsLoading] = useState(true)

  const typingRef = useRef<HTMLDivElement>(null)

  // Get unique types for filter
  const types = Array.from(new Set(tools.map((tool) => tool.type)))

  // Filter tools based on search term and filters
  const filteredTools = tools.filter((tool) => {
    const matchesSearch =
      tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesCategory = categoryFilter === "all" || tool.category === categoryFilter
    const matchesType = typeFilter === "all" || tool.type === typeFilter

    return matchesSearch && matchesCategory && matchesType
  })

  // Close welcome modal and save to localStorage
  const closeWelcomeModal = () => {
    setShowWelcomeModal(false)
    localStorage.setItem("welcomeModalShown", "true")
  }

  // Start security scan
  const startScan = () => {
    setIsScanning(true)
    setShowScanModal(true)
    setScanProgress(0)
    setScanComplete(false)

    // Simulate scanning progress
    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsScanning(false)
          setScanComplete(true)
          // Random number of threats between 0 and 3
          setThreatCount(Math.floor(Math.random() * 4))
          return 100
        }
        return prev + 2
      })
    }, 100)
  }

  // Simulate fixing threats
  const fixThreats = () => {
    setIsScanning(true)
    setScanProgress(0)

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsScanning(false)
          setThreatCount(0)
          return 100
        }
        return prev + 5
      })
    }, 100)
  }

  // Calculate security score for a tool (0-100)
  const getSecurityScore = (tool: Tool) => {
    // Base score on category
    let score = tool.category === "weak" ? 30 : tool.category === "medium" ? 60 : 85

    // Add points for features count
    score += Math.min(tool.features.length * 2, 10)

    // Add points for recent updates
    const updateDate = new Date(tool.lastUpdate)
    const now = new Date()
    const monthsDiff = (now.getFullYear() - updateDate.getFullYear()) * 12 + now.getMonth() - updateDate.getMonth()
    score -= Math.min(monthsDiff * 2, 15)

    // Ensure score is between 0-100
    return Math.max(0, Math.min(100, score))
  }

  // Typing animation effect
  useEffect(() => {
    if (typingRef.current && showWelcomeModal) {
      const text = "Добро пожаловать в базу данных OSINT инструментов. Система готова к использованию."
      let i = 0
      typingRef.current.textContent = ""

      const typing = setInterval(() => {
        if (i < text.length) {
          if (typingRef.current) {
            typingRef.current.textContent += text.charAt(i)
            i++
          }
        } else {
          clearInterval(typing)
        }
      }, 30)

      return () => clearInterval(typing)
    }
  }, [showWelcomeModal])

  // Fetch tools from Supabase
  useEffect(() => {
    const fetchTools = async () => {
      try {
        // Try to fetch from Supabase
        const { data, error } = await supabase.from("tools").select("*")

        if (error) {
          console.error("Error fetching from Supabase:", error)
          // Fallback to local data
          setTools(toolsData)
        } else if (data && data.length > 0) {
          setTools(data as Tool[])
        } else {
          // If no data in Supabase, use local data
          setTools(toolsData)

          // Optionally seed the database with local data
          // This is commented out to prevent accidental data insertion
          /*
          for (const tool of toolsData) {
            await supabase.from('tools').insert([tool])
          }
          */
        }
      } catch (error) {
        console.error("Error:", error)
        setTools(toolsData)
      } finally {
        setIsLoading(false)
      }
    }

    fetchTools()
  }, [])

  // Check localStorage on component mount
  useEffect(() => {
    const hasSeenWelcome = localStorage.getItem("welcomeModalShown")
    if (hasSeenWelcome) {
      setShowWelcomeModal(false)
    }
  }, [])

  return (
    <div className="min-h-screen bg-[#0a0e17] text-[#e6e6e6] font-mono">
      {/* Welcome Modal */}
      <Dialog open={showWelcomeModal} onOpenChange={setShowWelcomeModal}>
        <DialogContent className="bg-[#0f1623] border border-[#4ade80] text-[#e6e6e6] max-w-md rounded-lg shadow-[0_0_15px_rgba(74,222,128,0.3)] animate-fadeIn">
          <button
            onClick={closeWelcomeModal}
            className="absolute right-4 top-4 rounded-full p-1 text-[#4ade80] hover:bg-[#1a2436] transition-colors"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="absolute inset-0 bg-[#4ade80] blur-md opacity-20 rounded-full animate-pulse"></div>
              <img
                src="/placeholder.svg?height=64&width=64"
                alt="Logo"
                className="h-16 w-16 relative z-10 animate-float"
              />
            </div>
          </div>

          <DialogHeader className="text-center space-y-2">
            <DialogTitle className="text-xl font-mono tracking-wider text-[#4ade80]">Привет, бро!</DialogTitle>
            <div
              ref={typingRef}
              className="text-[#a0a0a0] text-sm font-mono border-l-2 border-[#4ade80] pl-3 py-1 mx-auto inline-block cursor-blink"
            ></div>
          </DialogHeader>

          <div className="my-4 bg-[#131c2e] border border-[#1e293b] p-3 font-mono text-xs text-[#a0a0a0]">
            <div className="flex items-center text-[#4ade80] mb-1">
              <Shield className="h-3 w-3 mr-1" />
              <span>СИСТЕМА_БЕЗОПАСНОСТИ</span>
            </div>
            <div className="ml-4">
              Сайт защищен от вредоносного ПО
              <br />
              Статус: <span className="text-[#4ade80]">АКТИВЕН</span>
              <br />
              Последняя проверка: {new Date().toLocaleDateString()}
            </div>
          </div>

          <DialogFooter className="mt-4">
            <Button
              onClick={closeWelcomeModal}
              className="w-full bg-[#131c2e] hover:bg-[#1a2436] text-[#4ade80] border border-[#4ade80] rounded-md font-mono tracking-wider hover:shadow-[0_0_10px_rgba(74,222,128,0.3)] transition-all"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-2"
              >
                <path d="M12 2a10 10 0 1 0 10 10H12V2Z" />
                <path d="M21.17 8H12V2.83c2 .52 3.84 1.68 5.17 3.17 1.5 1.33 2.66 3.17 3.17 5.17Z" />
              </svg>
              Форум
            </Button>
          </DialogFooter>

          <div className="text-center text-sm text-gray-400 mt-2">PS: @fametgs</div>
        </DialogContent>
      </Dialog>

      {/* Security Scan Modal */}
      <Dialog open={showScanModal} onOpenChange={setShowScanModal}>
        <DialogContent className="bg-[#0f1623] border border-[#4ade80] text-[#e6e6e6] max-w-md rounded-lg shadow-[0_0_15px_rgba(74,222,128,0.3)]">
          <DialogHeader className="text-center">
            <DialogTitle className="text-xl font-mono tracking-wider text-[#4ade80]">
              {isScanning ? "Сканирование..." : scanComplete ? "Сканирование завершено" : "Безопасность"}
            </DialogTitle>
          </DialogHeader>

          <div className="my-4">
            {isScanning && (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <Shield className="h-16 w-16 text-[#4ade80] animate-pulse" />
                </div>
                <Progress value={scanProgress} className="h-2 bg-[#1a2436]" indicatorClassName="bg-[#4ade80]" />
                <div className="text-center text-sm text-[#a0a0a0]">Проверка системы на наличие угроз...</div>
              </div>
            )}

            {scanComplete && (
              <div className="space-y-4">
                <div className="flex justify-center">
                  {threatCount > 0 ? (
                    <AlertTriangle className="h-16 w-16 text-yellow-500" />
                  ) : (
                    <CheckCircle2 className="h-16 w-16 text-[#4ade80]" />
                  )}
                </div>

                <div className="bg-[#131c2e] border border-[#1e293b] p-4 rounded-md">
                  <div className="text-center mb-2 font-medium">
                    {threatCount > 0 ? `Обнаружено угроз: ${threatCount}` : "Угрозы не обнаружены"}
                  </div>

                  {threatCount > 0 ? (
                    <div className="space-y-2 text-sm text-[#a0a0a0]">
                      <div className="flex items-start">
                        <span className="text-yellow-500 mr-2">•</span>
                        <span>Потенциально опасные файлы cookies</span>
                      </div>
                      {threatCount > 1 && (
                        <div className="flex items-start">
                          <span className="text-yellow-500 mr-2">•</span>
                          <span>Подозрительные скрипты отслеживания</span>
                        </div>
                      )}
                      {threatCount > 2 && (
                        <div className="flex items-start">
                          <span className="text-yellow-500 mr-2">•</span>
                          <span>Незащищенное соединение</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-sm text-[#a0a0a0] text-center">
                      Ваша система защищена. Продолжайте безопасную работу.
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="flex flex-col space-y-2">
            {scanComplete && threatCount > 0 ? (
              <Button
                onClick={fixThreats}
                className="w-full bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/50 rounded-md font-mono"
              >
                Устранить угрозы
              </Button>
            ) : (
              <Button
                onClick={() => setShowScanModal(false)}
                className="w-full bg-[#131c2e] hover:bg-[#1a2436] text-[#4ade80] border border-[#4ade80] rounded-md font-mono"
              >
                Закрыть
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <header className="border-b border-[#1e293b] bg-[#0f1623] py-4 px-6 sticky top-0 z-10">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <Terminal className="h-6 w-6 text-[#4ade80] mr-3" />
            <h1 className="text-xl font-mono tracking-wider text-[#4ade80]">OSINT_TOOLKIT</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={startScan}
              className="bg-[#131c2e] border-[#1e293b] text-[#4ade80] hover:bg-[#1a2436] hover:text-[#4ade80] rounded-md"
            >
              <Shield className="h-4 w-4 mr-2" />
              Проверка безопасности
            </Button>
            <div className="text-xs text-[#a0a0a0] font-mono hidden sm:block">
              <span className="text-[#4ade80]">&gt;</span> {filteredTools.length} инструментов найдено
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        <div className="bg-[#0f1623] border border-[#1e293b] mb-8 shadow-lg rounded-md overflow-hidden">
          <div className="p-4 border-b border-[#1e293b] flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-[#a0a0a0]" />
              <Input
                placeholder="Поиск инструментов..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 bg-[#131c2e] border-[#1e293b] text-[#e6e6e6] placeholder:text-[#a0a0a0] focus-visible:ring-[#4ade80] rounded-md font-mono"
              />
            </div>

            <div className="flex gap-2 flex-col sm:flex-row">
              <div className="relative">
                <Filter className="absolute left-3 top-3 h-4 w-4 text-[#a0a0a0]" />
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-full sm:w-[180px] bg-[#131c2e] border-[#1e293b] text-[#e6e6e6] focus:ring-[#4ade80] rounded-md pl-10 font-mono">
                    <SelectValue placeholder="Категория" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#131c2e] border-[#1e293b] text-[#e6e6e6] rounded-md font-mono">
                    <SelectItem value="all">Все категории</SelectItem>
                    <SelectItem value="weak">Weak</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="strong">Strong</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="relative">
                <Filter className="absolute left-3 top-3 h-4 w-4 text-[#a0a0a0]" />
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full sm:w-[180px] bg-[#131c2e] border-[#1e293b] text-[#e6e6e6] focus:ring-[#4ade80] rounded-md pl-10 font-mono">
                    <SelectValue placeholder="Тип" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#131c2e] border-[#1e293b] text-[#e6e6e6] rounded-md font-mono">
                    <SelectItem value="all">Все типы</SelectItem>
                    {types.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="flex justify-end items-center p-2 border-b border-[#1e293b] bg-[#131c2e]">
            <div className="flex gap-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setViewMode("grid")}
                className={`rounded-md border-[#1e293b] ${
                  viewMode === "grid"
                    ? "bg-[#4ade80] text-[#0f1623] border-[#4ade80]"
                    : "bg-[#131c2e] text-[#a0a0a0] hover:bg-[#1a2436] hover:text-[#e6e6e6]"
                }`}
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setViewMode("list")}
                className={`rounded-md border-[#1e293b] ${
                  viewMode === "list"
                    ? "bg-[#4ade80] text-[#0f1623] border-[#4ade80]"
                    : "bg-[#131c2e] text-[#a0a0a0] hover:bg-[#1a2436] hover:text-[#e6e6e6]"
                }`}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="p-12 flex justify-center items-center">
              <div className="animate-spin h-8 w-8 border-2 border-[#4ade80] border-t-transparent rounded-full"></div>
            </div>
          ) : viewMode === "grid" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
              {filteredTools.map((tool) => {
                const securityScore = getSecurityScore(tool)
                return (
                  <Card
                    key={tool.id}
                    className="h-full flex flex-col bg-[#131c2e] border border-[#1e293b] text-[#e6e6e6] rounded-md hover:shadow-[0_0_10px_rgba(74,222,128,0.15)] transition-all duration-300 hover:translate-y-[-2px]"
                  >
                    <CardHeader className="pb-2 border-b border-[#1e293b]">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg text-[#e6e6e6] font-mono">{tool.name}</CardTitle>
                        <Badge
                          className={`rounded-md font-mono text-xs ${
                            tool.category === "weak"
                              ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/50"
                              : tool.category === "medium"
                                ? "bg-orange-500/20 text-orange-400 border border-orange-500/50"
                                : "bg-red-500/20 text-red-400 border border-red-500/50"
                          }`}
                        >
                          {tool.category}
                        </Badge>
                      </div>
                      <div className="text-[#a0a0a0] text-xs font-mono mt-1">{tool.type}</div>
                    </CardHeader>
                    <CardContent className="flex-1 pt-3 text-sm">
                      <p className="text-[#a0a0a0] font-mono leading-relaxed">{tool.description}</p>
                      <div className="mt-4 bg-[#0f1623] border border-[#1e293b] p-2 rounded-md">
                        <div className="text-[#4ade80] text-xs font-mono mb-2 flex items-center">
                          <ChevronRight className="h-3 w-3 mr-1" />
                          <span>ФУНКЦИИ</span>
                        </div>
                        <ul className="space-y-1 text-xs text-[#a0a0a0] font-mono ml-4">
                          {tool.features.map((feature, index) => (
                            <li key={index} className="flex items-start">
                              <span className="text-[#4ade80] mr-1">+</span> {feature}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Security Score */}
                      <div className="mt-4">
                        <div className="flex justify-between items-center mb-1 text-xs">
                          <span className="text-[#a0a0a0]">Оценка безопасности</span>
                          <span
                            className={
                              securityScore >= 70
                                ? "text-[#4ade80]"
                                : securityScore >= 40
                                  ? "text-yellow-400"
                                  : "text-red-400"
                            }
                          >
                            {securityScore}%
                          </span>
                        </div>
                        <Progress
                          value={securityScore}
                          className="h-1.5 bg-[#1a2436]"
                          indicatorClassName={
                            securityScore >= 70 ? "bg-[#4ade80]" : securityScore >= 40 ? "bg-yellow-400" : "bg-red-400"
                          }
                        />
                      </div>
                    </CardContent>
                    <CardFooter className="flex flex-col items-start gap-2 border-t border-[#1e293b] pt-3 pb-4">
                      <div className="text-xs text-[#a0a0a0] font-mono">Обновлено: {tool.lastUpdate}</div>
                      <div className="flex gap-4 w-full">
                        <a
                          href={tool.downloadLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-[#4ade80] hover:text-[#3cbe6c] flex items-center gap-1 font-mono transition-colors"
                        >
                          <Download className="h-3 w-3" />
                          СКАЧАТЬ
                        </a>
                        {tool.demoLink && (
                          <a
                            href={tool.demoLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-[#4ade80] hover:text-[#3cbe6c] flex items-center gap-1 font-mono transition-colors"
                          >
                            <ExternalLink className="h-3 w-3" />
                            ДЕМО
                          </a>
                        )}
                      </div>
                    </CardFooter>
                  </Card>
                )
              })}
            </div>
          ) : (
            <div className="divide-y divide-[#1e293b]">
              {filteredTools.map((tool) => {
                const securityScore = getSecurityScore(tool)
                return (
                  <div key={tool.id} className="bg-[#131c2e] hover:bg-[#1a2436] transition-colors">
                    <div className="p-4">
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-2 mb-3">
                        <div>
                          <h3 className="text-lg text-[#e6e6e6] font-mono">{tool.name}</h3>
                          <div className="text-[#a0a0a0] text-xs font-mono mt-1 flex items-center gap-2">
                            <span>{tool.type}</span>
                            <span className="text-[#1e293b]">|</span>
                            <span>Обновлено: {tool.lastUpdate}</span>
                          </div>
                        </div>
                        <Badge
                          className={`rounded-md font-mono text-xs ${
                            tool.category === "weak"
                              ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/50"
                              : tool.category === "medium"
                                ? "bg-orange-500/20 text-orange-400 border border-orange-500/50"
                                : "bg-red-500/20 text-red-400 border border-red-500/50"
                          }`}
                        >
                          {tool.category}
                        </Badge>
                      </div>

                      <p className="text-[#a0a0a0] text-sm font-mono mb-3">{tool.description}</p>

                      <div className="flex flex-wrap gap-1 mb-3">
                        {tool.features.map((feature, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="bg-[#0f1623] text-[#a0a0a0] border-[#1e293b] rounded-md text-xs font-mono"
                          >
                            {feature}
                          </Badge>
                        ))}
                      </div>

                      {/* Security Score */}
                      <div className="mb-3">
                        <div className="flex justify-between items-center mb-1 text-xs">
                          <span className="text-[#a0a0a0]">Оценка безопасности</span>
                          <span
                            className={
                              securityScore >= 70
                                ? "text-[#4ade80]"
                                : securityScore >= 40
                                  ? "text-yellow-400"
                                  : "text-red-400"
                            }
                          >
                            {securityScore}%
                          </span>
                        </div>
                        <Progress
                          value={securityScore}
                          className="h-1.5 bg-[#1a2436]"
                          indicatorClassName={
                            securityScore >= 70 ? "bg-[#4ade80]" : securityScore >= 40 ? "bg-yellow-400" : "bg-red-400"
                          }
                        />
                      </div>

                      <div className="flex justify-end gap-4">
                        <a
                          href={tool.downloadLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-[#4ade80] hover:text-[#3cbe6c] flex items-center gap-1 font-mono transition-colors"
                        >
                          <Download className="h-3 w-3" />
                          СКАЧАТЬ
                        </a>
                        {tool.demoLink && (
                          <a
                            href={tool.demoLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-[#4ade80] hover:text-[#3cbe6c] flex items-center gap-1 font-mono transition-colors"
                          >
                            <ExternalLink className="h-3 w-3" />
                            ДЕМО
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}

          {filteredTools.length === 0 && (
            <div className="p-8 text-center">
              <div className="text-[#a0a0a0] font-mono mb-2">Инструменты не найдены</div>
              <div className="text-xs text-[#a0a0a0] font-mono">Попробуйте изменить параметры поиска</div>
            </div>
          )}
        </div>
      </main>

      <footer className="border-t border-[#1e293b] py-4 px-6 text-center text-xs text-[#a0a0a0] font-mono">
        <div className="container mx-auto">OSINT_TOOLKIT v1.0 | BETA | &copy; 2025</div>
      </footer>
    </div>
  )
}
