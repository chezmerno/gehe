export type Tool = {
  id: number
  name: string
  description: string
  category: "weak" | "medium" | "strong"
  type: string
  lastUpdate: string
  downloadLink: string
  demoLink?: string
  features: string[]
}
